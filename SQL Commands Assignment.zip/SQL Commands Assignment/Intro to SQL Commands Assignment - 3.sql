Create Database Classroom;

-- Access the Database Classroom

CREATE TABLE Science_Class(
Enrollment_NO serial primary key,
Name varchar(20),
Science_Marks int
);

INSERT INTO Science_Class(Name, Science_Marks) VALUES('Popeye', 33),('Olive',54),('Brutus', 98);

SELECT * FROM Science_Class;

-- Import Data from student.csv

SELECT * FROM Science_Class;

SELECT Name FROM Science_Class WHERE Science_Marks > 60;

SELECT * FROM Science_Class WHERE Science_Marks > 35 AND Science_Marks < 60;

UPDATE Science_Class SET Science_Marks = 45 WHERE Name = 'Popeye';

DELETE FROM Science_Class WHERE Name = 'Robb';

ALTER TABLE Science_Class RENAME Column Name to Student_Name;

-- Final Output in the Table Science_Class

SELECT * FROM Science_Class;

