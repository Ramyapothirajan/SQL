-- 1) a) Create a database named student_db.
CREATE DATABASE Student_DB;

-- b) Create a table named students_details with columns id (integer), name (varchar), age (integer), and grade (float). 
---   id should be set as the primary key.

CREATE TABLE Students_Details(
	ColumnID INT Primary Key,
	Name VARCHAR(30),
	Age INT NOT NULL,
	Grade FLOAT
);

-- c) Insert any four records into students_details.

INSERT INTO Students_Details VALUES
(91076, 'Pragya Ritej', 21, 8.46),
(80015, 'Revathi Raj', 20, 8.09),
(41134, 'Kavin Kumar', 19, 7.43),
(71889, 'Shristi', 22, 7.71),
(24015, 'Rukesh Pawan', 20, 8.68);

SELECT * FROM Students_Details;

-- d) Create a new table named students_details_copy with the same columns as students_details. 
--    id should also be set as the primary key.

CREATE TABLE Students_Details_Copy AS SELECT * FROM Students_Details;

SELECT * FROM Students_Details_Copy;

-- e) Create a trigger named after_insert_details that inserts a new record into students_details_copy every time a record is inserted into students_details.

CREATE FUNCTION Update_Detail()
RETURNS TRIGGER 
AS $$
BEGIN
    INSERT INTO Students_Details_Copy(ColumnId, Name, Age, Grade)
	VALUES(NEW.ColumnID, NEW.Name, NEW.Age, NEW.Grade);
	RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER After_Insert_Detail
AFTER INSERT ON Students_Details
FOR EACH ROW 
EXECUTE FUNCTION Update_Detail();

-- f) Insert a new record into students_details.

INSERT INTO Students_Details 
Values(62137, 'Dhakshu', 21, 7.96),(35427, 'Jai Pavni', 18, 8.73);
SELECT * FROM Students_Details;

-- g) check whether a record is filling in students_details_copy as you insert value in students_details.

SELECT * FROM Students_Details_Copy;

-- 2) a) Use student_db , 
-- b) Create a trigger named update_grade that automatically updates the grade column every time a record in students_details is updated based on the following criteria:
-- c) If the updated record has an age value less than 18, multiply the grade by 0.9.
-- d) If the updated record has an age value between 18 and 20 (inclusive), multiply the grade by 1.1.
-- e) If the updated record has an age value greater than 20, multiply the grade by 1.05.

CREATE FUNCTION New_Grade()
RETURNS TRIGGER
AS $$
BEGIN
   IF NEW.Age < 18 THEN 
      NEW.Grade := NEW.Grade * 0.9;
   ELSIF NEW.AGE BETWEEN 18 AND 20 THEN
      NEW.Grade := NEW.Grade * 1.1;
   ELSE
      NEW.Grade := NEW.Grade * 1.05;
   END IF;
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TABLE Students_New(LIKE Students_Details);

CREATE TRIGGER Update_Grade
BEFORE INSERT OR UPDATE ON Students_New
FOR EACH ROW
EXECUTE FUNCTION New_Grade();

-- f) Update the age value of one of the records in students_new to see the trigger in action.

INSERT INTO Students_New(ColumnID, Name, Age, Grade) 
SELECT ColumnID, Name, 23, Grade
FROM students_details
WHERE ColumnID = 71889
UNION ALL
SELECT ColumnID, Name, 20, Grade
FROM students_details
WHERE ColumnID = 41134;

SELECT * FROM Students_New;