--1) a.	Create a new database in your database management system, and name it Supermart_DB.

CREATE DATABASE Supermart_DB;

--b. Create a new table called "customers" in the Supermart_DB database. 

CREATE TABLE Customers(
	CustomerID VARCHAR Primary Key,
	CustomerName VARCHAR(30),
	Segment VARCHAR(15),
	Age int NOT NULL,
	Country VARCHAR,
	City VARCHAR,
	State VARCHAR,
	PostalCode INT NOT NULL,
	Region VARCHAR
);

--c. Load the data from the Customer.csv file into the customer’s table. 

SELECT * FROM Customers;

--d. Create a new table called "products" in the Supermart_DB database. 

CREATE TABLE Products(
	ProductID VARCHAR Primary Key,
	Category VARCHAR,
	Sub_Category VARCHAR,
	ProductName TEXT
);

--e. Load the data from the Product.csv file into the products table. 

SELECT * FROM Products;

--f.Create a new table called "sales" in the Supermart_DB database.

CREATE TABLE Sales(
	OrderLine SERIAL Primary Key,
	OrderID VARCHAR,
	OrderDate VARCHAR,
	ShipDate VARCHAR,
	ShipMode VARCHAR,
	CustomerID VARCHAR,
	ProductID VARCHAR,
	Sales FLOAT,
	Quantity INT NOT NULL,
	Discount FLOAT,
	Profit FLOAT
);

--g. Load the data from the Sales.csv file into the sales table. 

SELECT * FROM Sales;

--SELECTION OPERATORS:
--1) a. Get the list of all the cities where the region is north or east without any duplicates using the IN statement.

SELECT DISTINCT city FROM Customers WHERE region IN ('North', 'East');

--b. Get the list of all orders where the ‘sales’ value is between 100 and 500 using the BETWEEN operator.

SELECT OrderID, OrderDate, ProductID, CustomerID, Sales, Profit
FROM sales WHERE sales BETWEEN 200 AND 500;

--c. Get the list of customers whose last name contains only 4 characters using LIKE.

SELECT CustomerName FROM Customers WHERE CustomerName LIKE '% ____';

--1. Retrieve all orders where the ‘discount’ value is greater than zero ordered in descending order basis ‘discount’ value.

SELECT * FROM Sales WHERE Discount > 0 ORDER BY Discount DESC;

--2. Limit the number of results in the above query to the top 10.

SELECT * FROM Sales WHERE Discount > 0 ORDER BY Discount DESC LIMIT 10;

--AGGREGATE OPERATORS:
--1. Find the sum of all ‘sales’ values.

SELECT SUM(Sales) FROM Sales;

--2. Find count of the number of customers in the north region with ages between 20 and 30

SELECT COUNT(CustomerID) FROM Customers WHERE Region=('North') AND 
Age BETWEEN 20 AND 30;

--3. Find the average age of east region customers.

SELECT AVG(Age) AS Average_Age FROM Customers WHERE Region='East';

--4. Find the minimum and maximum aged customers from Philadelphia.

SELECT CustomerID, CustomerName, Age FROM Customers
WHERE City = 'Philadelphia' AND 
(Age = (SELECT MIN(Age) FROM Customers WHERE City = 'Philadelphia')
OR Age = (SELECT MAX(Age) FROM Customers WHERE City = 'Philadelphia'));

-- GROUP BY OPERATORS:
--1. Create a display with the information below for each product ID.
--a. Total sales (in $) order by this column in descending 

SELECT ProductID, SUM(Sales) AS TotalSales FROM Sales
GROUP BY ProductID;

--b. Total sales quantity

SELECT ProductID, SUM(Quantity) AS TotalSales_Quantity FROM Sales
GROUP BY ProductID;

--c. The number of orders

SELECT ProductID, COUNT(OrderLine) AS TotalOrders FROM Sales
GROUP BY ProductID;

--d. Max Sales value

SELECT ProductID, MAX(Sales) AS MaximumSalesValue FROM Sales
GROUP BY ProductID
ORDER BY MaximumSalesValue DESC;

--e. Min Sales value

SELECT ProductID, MIN(Sales) AS MinimumSalesValue FROM Sales
GROUP BY ProductID
ORDER BY MinimumSalesValue;

--f. Average sales value

SELECT ProductID, AVG(Sales) AS AverageSalesValue FROM Sales
GROUP BY ProductID
ORDER BY AverageSalesValue DESC;

--2. Get the list of product ID’s where the quantity of product sold is greater than 10.

SELECT ProductID, SUM(Quantity) AS QuantityofProduct FROM Sales
GROUP BY ProductID
HAVING SUM(Quantity) > 10
ORDER BY QuantityofProduct DESC;
