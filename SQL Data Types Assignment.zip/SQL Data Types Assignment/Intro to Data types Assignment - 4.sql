CREATE DATABASE SALES;

-----Access the Database------

CREATE TABLE sales(
	"Order Line" SERIAL PRIMARY KEY,
	"Order ID" CHAR(8) not null UNIQUE,
	"Category" VARCHAR(20),
	"Product Name" VARCHAR(30),
	"Ordered Date" DATE,
	"Ordered Time" TIME,
	"Payment status" BOOLEAN,
	"Ship_time Details" TIMESTAMP,
	"Quantity" INT not null,
	"Discount" DECIMAL(5,2),
	"Shipping Address" TEXT,
	"Customer Feedback" TEXT
);

INSERT INTO sales("Order ID", "Category", "Product Name", "Ordered Date", "Ordered Time", "Payment status", "Ship_time Details", "Quantity", "Discount", "Shipping Address", "Customer Feedback") 
VALUES
('RY3479', 'Furniture', 'Dining Table', '2022-07-21', '16:46:23', TRUE, '2022-07-23 10:20:34', 1, 11.50,'13/A, Jiant Colony,Bangalore - 560046', 'The Table is very comforatble and satisfied our expectation, Thankyou for the timely delivery'), 
('TX4526', 'Mobile', 'Realme 9Pro', '2022-08-12', '12:34:12', TRUE, '2022-08-14 09:50:44', 2, 8.00,'21/C, S.S.Nagar, Hyderabad - 500016', 'Most Satisfied, excellent quality'),
('QW7634', 'Mobile', 'Redmi 11', '2022-07-02', '11:30:22', TRUE, '2022-07-04 18:23:17', 1, 5.00,'68, Shanti nagar, Hyderabad - 500006', 'High Quality'),
('YU5342', 'Earphones', 'Boat 199', '2022-06-25', '10:12:23', TRUE, '2022-06-26 20:00:10', 3, 9.50,'7/1 DJ colony, Bangalore - 560016', 'Most Satisfied'),
('IP9078', 'Home Decor', 'Dream Catcher', '2022-08-17', '12:56:02', FALSE, '2022-08-19 16:30:38', 5, 3.70,'67, Jaya Nagar, Chennai - 600003', 'Very Nice'),
('TE4327', 'Electronic Item', 'Mobile Charger', '2022-09-20', '15:44:02', TRUE, '2022-09-22 12:33:24', 2, 0.00,'3/D2, AGR Colony, Andhra - 515045', 'Working good'),
('PP3410', 'Dress', 'Kurti_Women', '2022-04-21', '14:04:11', FALSE, '2022-04-22 19:30:23', 2, 15.50,'32, SK Nagar, Andhra - 515011', 'Beautiful and good material'),
('KM908', 'Accessories', 'Bangles', '2022-08-19', '16:21:09', TRUE, '2022-08-21 11:50:36', 5, 7.00,'A3 block, S.S, MG Colony, Chennai - 600003', 'Expectation satisfied'),
('UI786', 'Shoes', 'Adidas_Men', '2022-07-07', '15:01:11', TRUE, '2022-07-08 17:50:12', 1, 4.80,'4, Kamarajpuram, Telangana - 508216', 'Comfortable'),
('WR341', 'Furniture', 'Sofa', '2022-09-14', '19:56:07', FALSE, '2022-09-17 14:30:22', 1, 5.70,'45/D, Abhyank Nagar, Nagpur - 440005', 'Nice and Comfortable'),
('KL9001', 'Mobile', 'Realme 10Pro', '2022-05-30', '22:12:37', TRUE, '2022-06-01 09:40:34', 3, 10.00,'C/7, NG colony, Pune - 411020', 'Good Quality');

SELECT * FROM sales;

ALTER TABLE sales ALTER COLUMN "Discount" TYPE FLOAT;

ALTER TABLE sales ALTER COLUMN "Shipping Address" TYPE VARCHAR(100);

SELECT * FROM sales;